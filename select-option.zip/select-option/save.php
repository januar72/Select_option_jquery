<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
</head>
<style type="text/css">
    body{
        margin: auto;
        width: 600px;
        border: 1px solid black;
        padding: 10px;
        border-radius: 5px;
    }
    button{
        width: 200px;
        height: 50px;
        margin: 10px;
        border: none;
        cursor: pointer;
        background-color: #e2edff;
        font-family: sans-serif;
        font-weight: bold;
        box-shadow: 5px 10px 10px;
    }
</style>
<body>
<form id="form-input" method="post">
    <div class="form-group">
        <label>Nama Siswa</label>
        <input type="text" name="nama" id="nama" class="form-control">
    </div>
    <div class="form-group">
        <label>Fakultas</label>
        <select name="fakultas" id="fakultas" class="form-control">
            <option>--Fakultas--</option>
            <?php $cam=mysqli_query($konek, "SELECT * FROM tbl_fakultas");
            while ($c=mysqli_fetch_array($cam)) {?>
                <option value="<?php echo $c['id_fakultas']; ?>"><?php echo $c['fakultas_nama']; ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="form-group">
        <label>Add Jurusan</label>
        <input type="text" name="jurusan" id="jurusan" required class="form-control">
    </div>
    <button type="submit" class="simpan" class="btn btn-danger">Simpan</button>
</form>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script type="text/javascript">
     $(document).ready(function(){
        $(".simpan").click(function(){
            var data =$('#form-input').serialize();
            $.ajax({
                type : 'POST',
                url : 'aksi.php',
                data : data,
                success: function(){
                    $('.tampildata').load('tampil.php');
                }
            });
        });
     });
 </script>
 <a href="input.php" style="font-style: italic; text-decoration: underline; color: red;">Back to index</a>
</html>