<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<div class="container">
	<table class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Fakultas</th>
				<th>Jurusan</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$no=1;
			$kam =mysqli_query($konek, "SELECT * FROM tbl_jurusan");
			while ($dat=mysqli_fetch_array($kam)) {
				?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $dat['nama']; ?></td>
					<td><?php echo $dat['jurusan_fakultas']; ?></td>
					<td><?php echo $dat['jurusan_nama']; ?></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>
</div>
</body>
</html>