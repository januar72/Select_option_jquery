<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Select Option Otomatis with Ajax</title>
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
</head>
<style type="text/css">
    body{
        margin: auto;
        width: 600px;
        border: 1px solid black;
        padding: 10px;
        border-radius: 5px;
    }
    button{
        width: 200px;
        height: 50px;
        margin: 10px;
        border: none;
        cursor: pointer;
        background-color: #e2edff;
        font-family: sans-serif;
        font-weight: bold;
        box-shadow: 5px 10px 10px;
    }
</style>
<body>
<a href="save.php" style="font-style: italic; text-decoration: underline;">Input data</a>
<a href="tampil.php" style="font-style: italic; color: salmon; text-decoration: underline;">cek data</a>
<form method="post">
	<div class="form-group">
		<label>Fakultas</label>
		<select name="fakultas" id="fakultas" class="form-control" required>
			<option>--fakultas--</option>
			<?php
			$tam =mysqli_query($konek, "select * from tbl_fakultas");
			while ($f =mysqli_fetch_array($tam)) { ?>
				<option value="<?php echo $f['id_fakultas'] ?>"><?php echo $f['fakultas_nama']; ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="form-group">
		<label>Jurusan</label>
		<select name="jurusan" id="jurusan" required class="form-control">
		</select>
	</div>
</form>
<div class="tampildata"></div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
	$('#fakultas').change(function(){
		var fakultas =$(this).val();
		$.ajax({
			type : 'POST',
			url : 'ajax_jurusan.php',
			data : 'id_fakultas=' + fakultas,
			success: function(response){
				$('#jurusan').html(response);
                $('.tampildata').load('tampil.php');
			}
		});
	});
</script>
</html>