<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$fakultas =$_POST['fakultas'];
$jurusan =$_POST['jurusan'];

$tampil =mysqli_query($konek, "INSERT INTO `tbl_jurusan` (`jurusan_id`,`nama`,`jurusan_fakultas`,`jurusan_nama`) VALUES (null, '$nama','$fakultas','$jurusan')");

 ?>