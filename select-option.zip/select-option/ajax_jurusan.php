<?php 
include 'koneksi.php';

$fakultas =$_POST['id_fakultas'];
$tampil =mysqli_query($konek, "SELECT * FROM tbl_jurusan WHERE jurusan_fakultas='$fakultas'");
$jml =mysqli_num_rows($tampil);
if ($jml > 0) {
	while ($r =mysqli_fetch_array($tampil)) { ?>
		<option value="<?php echo $r['jurusan_nama']; ?>"><?php echo $r['jurusan_nama']; ?></option>
		<?php 
			}
		}else{
			echo "<option>Data Jurusan Kosong</option>";
		} ?>