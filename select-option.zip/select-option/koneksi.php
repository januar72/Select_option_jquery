<?php 
$host 	="localhost";
$user 	="root";
$pass 	="";
$db 	="db_kampus";

$konek =mysqli_connect($host, $user, $pass, $db);


 ?>